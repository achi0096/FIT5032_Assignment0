<script setup>
import BHeader from './components/BHeader.vue'
</script>

<template>
  <div class="main-container">
    <header>
      <BHeader />
    </header> 
  
    <main class="main-box">
     <router-view /> 
    </main>
  </div>
</template>
