<template>
  <div class="container mt-4">
    <h2>Access denied</h2>
    <p>You must log in to view this page.</p>
    <router-link to="/login" class="btn btn-secondary">Go to Login</router-link>
  </div>
</template>
<script setup></script>
